package Bean;

public class JJimBean {

}
